/**
 * @author Liyabona Saki
 * @St_Number 217120830
 * @version 1
 */



package decryptionapp;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import java.util.*;




public class DecryptionApp extends JFrame implements ActionListener {

    private static Scanner key = new Scanner(System.in);
    //Jpanels
    private JPanel panelCenter;
    private JPanel panelNorth;
    private JPanel panelSouth;
    
    
    //Jlabels
    private JLabel DecryptLabel;
    private JLabel DukeLogo;
    
    //JTextFields
    private JTextArea PlainText;
    
    
    //Jbuttons
    private JButton btnDecrypt, btnClear, btnExit;
    
    //font
      private Font ft1, ft2, ft3;
    
  public DecryptionApp(){
      
      this.setTitle("My Decryption Application ver 1.0");
        
         panelNorth = new JPanel();
         panelCenter = new JPanel();
         panelSouth = new JPanel();
         
        
         
         DukeLogo = new JLabel(new ImageIcon("duke.running.gif"));
        
         DecryptLabel = new JLabel("Decrypt It!");
      
         PlainText = new JTextArea();
         
         btnDecrypt = new JButton("Decrypt");
         btnClear = new JButton("Clear");
         btnExit = new JButton("Quit");
         
        ft1 = new Font("Arial", Font.BOLD, 32);
        ft2 = new Font("Arial", Font.PLAIN, 22);
        ft3 = new Font("Arial", Font.PLAIN, 24);
  }
  
  public void setGUI(){
//      this.setSize(1820, 1200);
      
      panelNorth.setLayout(new FlowLayout());
      panelCenter.setLayout(new GridLayout(1, 3));
      panelSouth.setLayout(new GridLayout(1, 3));
      
      panelNorth.add(DukeLogo);
      panelNorth.add(DecryptLabel);
      DecryptLabel.setFont(ft1);
      DecryptLabel.setForeground(Color.RED);
      
      
      //Adding the text area to the center
      PlainText.setSize(600,300);
      PlainText.setFont(ft2);
      panelCenter.add(PlainText);
      
        this.add(panelNorth, BorderLayout.NORTH);
        this.add(panelCenter, BorderLayout.CENTER);
        this.add(panelSouth, BorderLayout.SOUTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        

        
        //adding buttons to south panel
        btnDecrypt.setFont(ft3);
        btnClear.setFont(ft3);
        btnExit.setFont(ft3);
        panelSouth.add(btnDecrypt);
        panelSouth.add(btnClear);
        panelSouth.add(btnExit);
        
        //listening to our buttons when they are clicked 
        btnDecrypt.addActionListener(this);
        btnClear.addActionListener(this);
        btnExit.addActionListener(this);
      
        //settting the GUI size
       this.setSize(600, 600);
       this.pack();
       this.setVisible(true);
  }
  

 
    
// ===== BUTTONS SECTION ========
  
   @Override
    public void actionPerformed(ActionEvent ae) {
        
      if (ae.getActionCommand().equals("Decrypt")) {
        
            String line;
            String fileName = "encryptedmessage.txt";
          
            try {
           
                FileReader fileReader =  new FileReader("encryptedmessage.txt");
                
                try 
                    (BufferedReader bufferedReader = new BufferedReader(fileReader)) {
                        while((line = bufferedReader.readLine()) != null) {
                        PlainText.setText(decrypt(line, 3));
                        }
                     }
                
                }//end try
            
                catch(FileNotFoundException e) {
                System.out.println("File not found");
                e.getStackTrace();
             }//end catch
            
            catch(IOException e){
            System.out.println("Error reading file '" + "encryptedmessage.txt" + "'"); 
            e.getStackTrace();
            
         }//end catch

      }
     
      
      
      //Clear button
      else if (ae.getActionCommand().equals("Clear")) {
           PlainText.setText(null);

        } 
      //Quit buttons
        else if (ae.getActionCommand().equals("Quit")) {
            System.exit(0);
        }
      
      }
    
    
    //Decrypt method
    public static String decrypt(String str, int key) {
   
    String decrypt = "";
    for(int i = 0; i < str.length(); i+=3 ){
        decrypt +=(char) (Integer.parseInt(str.substring(i,i+3)));
        }
        return decrypt;
    }
    
 
}
