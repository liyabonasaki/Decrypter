/**
 * @author Liyabona Saki
 * @St_Number 217120830
 * @version 1
 */

package decryptionapp;

public class DecryptMain {

 
    public static void main(String[] args) {
        // TODO code application logic here
        
         new DecryptionApp().setGUI();
         

      
    }
    
}
